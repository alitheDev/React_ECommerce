//Dependencies
import React, { Component } from 'react';
import {Icon} from 'react-materialize';
import { Link } from 'react-router-dom';
//Internals
import PRODUCTS from '../Data';
import './styles.css';

class Accessories extends Component {
  render() {
    return(
      <div className="accessories">
        <div className="accessories-title">
      
      
        <div class="ppagination">
  <a href="#">&laquo;</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a class="active" href="#">1</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">2</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">3</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">4</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">5</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">6</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#">&raquo;</a>
</div>




          <h4>Premium Accessories</h4>
        </div>
        <div className="items">
          {PRODUCTS.map((product) => {
            if (product.category === "accessories") {
              return(
                <div className="item">
                  <Link to={`/products/${product.id}`}>
                  
                  <div className="product-img">
                    <img alt={product.name} src={product.img} />
                  </div>
                  
                  <div className="product-details">
                    <h1 id="product-name">{product.name}</h1>
                    <h4 id="product-description">{product.description}</h4>
                  </div>
                  
                  </Link>
                  <div className="price-add">
                    <h5 id="product-price">${product.price}</h5>
                               
                    </div>

                    
                
                </div>
              )
            }
          })}
        </div>
      </div>
    );
  }
}

export default Accessories;
