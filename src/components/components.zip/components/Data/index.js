const products = [
  {
    id: 1,
    name: "Brown Shirt",
    description: "Brown T-Shirt for Women",
    price: 16.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/kOhL6k/img1.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 2,
    name: "Light Brown Shirt",
    description: "Light Brown Shirt for Women",
    price: 4.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/nNmKz5/img2.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 3,
    name: "Women Grey Shirt",
    description: "Grey Shirt for Women",
    price: 14.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/n6iMCQ/img3.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 4,
    name: "Warm Shirt Women",
    description: "Woolen Hoodie Women",
    price: 20.00,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/dVfORk/img4.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 5,
    name: "Women Grey Shirt",
    description: "Light Grey Shirt for Women",
    price: 4.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/jpMxmk/img5.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 6,
    name: "Women Red/Brown Shirt",
    description: "Red/Brown Blouse for Women",
    price: 19.99,
    gender: "women",
    type: "blouse",
    img: "https://image.ibb.co/mJppz5/img6.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 7,
    name: "Dark Grey Shirt Women",
    description: "Dark Grey Shirt for Women",
    price: 6.00,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/eZiSmk/img7.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 8,
    name: "White Shirt Women",
    description: "White Shirt for Women",
    price: 14.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/dyCysQ/img8.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 9,
    name: "Black Shirt Women",
    description: "Black Shirt for Women",
    price: 20.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/eOYre5/img10.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 10,
    name: "No Shoulder Hoodie",
    description: "Hoodie for Women",
    price: 4.99,
    gender: "women",
    type: "shirt",
    img: "https://image.ibb.co/f6gcK5/img9.jpg",
    inCart: false,
    category: "clothes"
  },
  {
    id: 11,
    name: "Women Watch Gold",
    description: "Golden Watch for Women",
    price: 45.99,
    gender: "women",
    type: "watch",
    img: "https://eu.louisvuitton.com/images/is/image/lv/1/PP_VP_L/louis-vuitton-speedy-bandouliere-20--M46575_PM2_Front%20view.jpg",
    inCart: false,
    category: "accessories"
  },
  {
    id: 12,
    name: "Louis Vitton mens belt",
    description: "Black Pearl Necklace for Women",
    price: 14.99,
    gender: "women",
    type: "necklace",
    img: "http://shopism.pk/image/cache/catalog/Mens%20Belts/Brown%20LV%20Silver%20Logo%20Buckle%20Stylish%20Belt%20SJ-118/5591380969f5e-brown-lv-silver-logo-buckle-stylish-belt-sj-118-dp-800x800.jpg",
    inCart: false,
    category: "accessories"
  },
  {
    id: 13,
    name: "Man Black Shirt",
    description: "Black T-Shirt for Men",
    price: 10.99,
    gender: "men",
    type: "shirt",
    img: "http://media.istockphoto.com/photos/smiling-young-man-in-blank-black-tshirt-picture-id464946525?k=6&m=464946525&s=612x612&w=0&h=KAjCFoJGDcFcx8R33Tq1vzqbfixh1XwGpFeiRNoTkRQ=",
    inCart: false,
    category: "clothes"
  },
  {
    id: 14,
    name: "Man Grey Tanktop",
    description: "Grey Tanktop for Men",
    price: 14.99,
    gender: "men",
    type: "shirt",
    img: "http://media.istockphoto.com/photos/portrait-of-young-man-wearing-tshirt-picture-id465207699?k=6&m=465207699&s=612x612&w=0&h=wSacC0bmcrekig1DW8lOwH7y3X0e4R9266-TuivVQJA=",
    inCart: false,
    category: "clothes"
  },
  {
    id: 15,
    name: "Man White Shirt",
    description: "White Shirt for Men",
    price: 20.99,
    gender: "men",
    type: "shirt",
    img: "http://media.istockphoto.com/photos/young-man-wearing-a-white-shirt-picture-id465331977?k=6&m=465331977&s=612x612&w=0&h=-K3c5eE2dZGmg6d5BrBfxOvcHRP7PwHrylyjuEVjbZo=",
    inCart: false,
    category: "clothes"
  },
  {
    id: 16,
    name: "Man Brown Shirt",
    description: "Brown Shirt for Men",
    price: 13.99,
    gender: "men",
    type: "shirt",
    img: "http://media.istockphoto.com/photos/young-man-looks-to-the-side-picture-id184616842?k=6&m=184616842&s=612x612&w=0&h=SmtsffRByKDH4_HtzGY8bWvHgH8o_4epWVPogvfJXnk=",
    inCart: false,
    category: "clothes"
  },
  {
    id: 17,
    name: "Atlectio Shirt",
    description: "Black Tie for Men",
    price: 13.99,
    gender: "men",
    type: "tie",
    img: "http://cartoblography.com/wp-content/uploads/2021/08/Miniero_2021.png",
    inCart: false,
    category: "accessories"
  },
  {
    id: 18,
    name: "Black Shirt Men",
    description: "Black Shirt for Men",
    price: 9.99,
    gender: "men",
    type: "shirt",
    img: "http://media.istockphoto.com/photos/smiling-man-in-a-black-t-shirt-picture-id520883622?k=6&m=520883622&s=612x612&w=0&h=XuxfQE0EOo_uWqA8SzNJvZ9Vn-sKR_cT4J9GRIudE4U=",
    inCart: false,
    category: "clothes"
  },
  {
    id: 19,
    name: "Nike Air Force 1",
    description: "Ties for Men",
    price: 35.99,
    gender: "men",
    type: "tie",
    img: "https://www.ymeuniverse.com/images/71532/315260-4.jpg",
    inCart: false,
    category: "accessories"
  },
  {
    id: 20,
    name: "iPad Max",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://whatmobilez.com/wp-content/uploads/2021/10/apple-ipad-mini-x.jpg",
    inCart: false,
    category: "accessories"
  },

  {
    id: 21,
    name: "Perfect Slippers",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://johnlewis.scene7.com/is/image/JohnLewis/238086343?$rsp-pdp-port-640-82$ ",
    inCart: false,
    category: "accessories"
  },


  {
    id: 22,
    name: "Sony Xperia 1",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://b1730387.smushcdn.com/1730387/wp-content/uploads/2020/02/wp-15825396720345863941801885034807-e1582573909866.jpg?lossy=1&strip=1&webp=1",
    inCart: false,
    category: "accessories"
  },

  {
    id: 23,
    name: "Apple Watch Latest Version",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://media.vogue.co.jp/photos/5f97c502fc6340ff71cc7e07/master/w_1600%2Cc_limit/hermes.jpg",
    inCart: false,
    category: "accessories"
  },


  {
    id: 24,
    name: "Blackberry Priv",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://pricematch.pk/uploadedstuff/productimages/03-BlackBerry-Priv.jpg",
    inCart: false,
    category: "accessories"
  },


  {
    id: 25,
    name: "Nokia 8",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://static-01.daraz.pk/p/bb8e09a70b1d2e90bf623306ea9d3e28.jpg ",
    inCart: false,
    category: "accessories"
  },


  {
    id: 26,
    name: "iPhone 14 Pro Max",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/iphone-14-pro-max-colors.png",
    inCart: false,
    category: "accessories"
  },


  {
    id: 27,
    name: "Samsung A23",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://www.pakmobizone.pk/wp-content/uploads/2022/04/Samsung-Galaxy-A23-Awesom-White-12.jpg",
    inCart: false,
    category: "accessories"
  },


  {
    id: 28,
    name: "Denim Jacket",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://di2ponv0v5otw.cloudfront.net/posts/2021/11/09/618abc7688cce3219f24f399/s_618abccf88cce3f6db24f5d0.jpg",
    inCart: false,
    category: "accessories"
  },


  {
    id: 29,
    name: "Skin Lotion",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://static.beautytocare.com/media/catalog/product/cache/global/image/1300x1300/85e4522595efc69f496374d01ef2bf13/n/i/nivea-irresistibly-smooth-body-lotion-400ml.jpg ",
    inCart: false,
    category: "accessories"
  },


  {
    id: 30,
    name: "Women Shoes",
    description: "Black Tie for Men",
    price: 15.99,
    gender: "men",
    type: "tie",
    img: "https://cdn.shopify.com/s/files/1/0055/5525/7462/products/L-EK-0400877_2.jpg?v=1661748998&width=1280 ",
    inCart: false,
    category: "accessories"
  },










];

export default products;
