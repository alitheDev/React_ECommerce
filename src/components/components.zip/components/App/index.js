// Dependencies
import React from 'react';
//Internals
import Products from '../Items';
import './index.css';

const App = () => (
  <div className="content">
    <Products />
  </div>
);

export default App;
