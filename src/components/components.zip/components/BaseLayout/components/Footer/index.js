//Dependencies
import React from 'react';
//Internals
import './index.css';

const Footer = () => (
  <div className="footer">
  <h1></h1>  
    <p>© 2023 Copyright &nbsp;&nbsp; | &nbsp;&nbsp;  muhammadalisohail7996@gmail.com &nbsp;  </p>
  
  </div>
)

export default Footer;
